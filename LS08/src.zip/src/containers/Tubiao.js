import React, { Component } from 'react'

export default class Tubiao extends Component {
    render() {
        return (
            <div>
                图表
            </div>
        )
    }
}
