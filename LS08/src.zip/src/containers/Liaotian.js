import React, { Component } from 'react'

export default class Liaotian extends Component {
    render() {
        return (
            <div>
                聊天室
            </div>
        )
    }
}
