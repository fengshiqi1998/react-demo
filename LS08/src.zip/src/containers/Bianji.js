import React, { Component } from 'react'

export default class Bianji extends Component {
    render() {
        return (
            <div>
                编辑器
            </div>
        )
    }
}
